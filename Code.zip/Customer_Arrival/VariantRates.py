#/usr/bin/python3

from random import expovariate as exp
from scipy.stats import norm
from scipy.integrate import dblquad
import numpy as np

class VariantRate():
    def __init__(self, rates):
        self.rates = rates
        self.time = 0
        self.duration = 480 #minutes
        self.weight = self._weight_function()
        self.next_arrivals = [ exp(rate * self.weight(self.time)) if rate > 0 else np.inf for rate in rates ]

        #print(min(self.next_arrivals), max(self.next_arrivals))
        #input()

    def _indexed_min_arrival(self):
        i, v = min(enumerate(self.next_arrivals), key=lambda p: p[1])
        return (i, v)

    def _weight_function(self):
        mu1 = -1 # 9am
        mu2 = 7 # 5am
        std = 1 # 95% of traffic in 2 hours from spike?
        s1, s2 = norm(mu1, std).pdf, norm(mu2, std).pdf

        def traffic_curve(t):
            return s1(t) + s2(t)

        #scale = dblquad(lambda t, x:traffic_curve(t/60) * np.exp(-traffic_curve(t/60) * x),
        #        0, np.inf, lambda x:0, lambda x: self.duration/60)[0]
        #print(scale)
        #input()

        return lambda t: traffic_curve(t/60) * 8 # / scale

    def step(self, size):
        arrival_indices = dict()
        time_elapsed = 0

        min_i, min_t = self._indexed_min_arrival()
        while min_t + time_elapsed < size:
            self.time += min_t
            arrival_indices[min_i] = arrival_indices.get(min_i, 0) + 1
            time_elapsed += min_t
            self.next_arrivals = [ arr - min_t for arr in self.next_arrivals ]
            self.next_arrivals[min_i] = exp(self.rates[min_i] * self.weight(self.time))
            min_i, min_t = self._indexed_min_arrival()

        time_remaining = size - time_elapsed
        self.next_arrivals = [ arr - time_remaining for arr in self.next_arrivals ]
        self.time += time_remaining

        return arrival_indices

DefaultCustomers = VariantRate
