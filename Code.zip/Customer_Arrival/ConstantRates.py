#/usr/bin/python3

from random import expovariate as exp
from numpy import inf

class ConstRate():
    def __init__(self, rates):
        self.rates = rates
        self.next_arrivals = [ exp(rate) if rate > 0 else inf for rate in rates ]

    def _indexed_min_arrival(self):
        i, v = min(enumerate(self.next_arrivals), key=lambda p: p[1])
        return (i, v)

    def step(self, size):
        arrival_indices = dict()
        time_elapsed = 0

        min_i, min_t = self._indexed_min_arrival()
        while min_t + time_elapsed < size:
            arrival_indices[min_i] = arrival_indices.get(min_i, 0) + 1
            time_elapsed += min_t
            self.next_arrivals = [ arr - min_t for arr in self.next_arrivals ]
            self.next_arrivals[min_i] = exp(self.rates[min_i])
            min_i, min_t = self._indexed_min_arrival()

        self.next_arrivals = [ arr - size + time_elapsed for arr in self.next_arrivals ]

        return arrival_indices

DefaultCustomers = ConstRate
