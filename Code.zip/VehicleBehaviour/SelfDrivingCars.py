#!/usr/bin/python3

from .BaseVehicleDriver import Driver

class SelfDrivingCar(Driver):
    def drive(self):
        if self.route == None or self.passenger_steps > 0:
            Driver.drive(self)
            return

        # Don't move if route is empty
        if self.route:
            self.location = self.route.pop(0)

DefaultDriver = SelfDrivingCar
