#!/usr/bin/python3

from .BaseVehicleDriver import Driver
from random import random as unif

class HumanDriver(Driver):
    def __init__(self, location, can_reroute = True):
        Driver.__init__(self, location, can_reroute)
        self.sequential_routes = 0
        self.got_new_route = False

    def setRoute(self, route):
        self.got_new_route = True
        if self._realise_route():
            self.route = route

    def _realise_route(self):
        return unif() > 0.25 / ( 2 ** self.sequential_routes ) 

    def drive(self):
        if self.got_new_route:
            self.got_new_route = False
            self.sequential_routes += 1
        else:
            self.sequential_routes = 0

        if self.route == None or self.passenger_steps > 0:
            Driver.drive(self)
            return

        # Don't move if route is empty
        if self.route:
            self.location = self.route.pop(0)

DefaultDriver = HumanDriver
