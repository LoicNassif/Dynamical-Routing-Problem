#!/usr/bin/python

from random import choice

class Driver():
    def __init__(self, location, can_reroute = True):
        self.location = location
        self.route = None
        self.passenger_steps = 0
        self.can_reroute = can_reroute

    def is_available(self):
        return self.passenger_steps == 0 and (self.can_reroute or self.route == None)

    def setRoute(self, route):
        self.route = route

    def clearRoute(self):
        self.route = None

    def pickup_passenger(self):
        # Assume all trips are of random length between 3 and 15 blocks
        self.passenger_steps = choice(range(3, 16))
        self.route = None

    def drive(self):
        # This driver always drives uniformly randomly
        self.location = choice(self.location.neighbours)[0]
        if self.passenger_steps > 0:
            self.passenger_steps -= 1
