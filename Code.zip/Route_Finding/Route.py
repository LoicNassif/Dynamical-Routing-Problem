#!/usr/bin/python3

class Route():
    def __init__(self, start, end, dist, route=None):
        # bad names, as this is also valid for reversing the route
        path = frozenset({start, end})
        __init__(self, path, dist, route=route)
        
    def __init__(self, path, dist, route=None):
        self.path = path
        self.dist = dist

        if route == None:
            route = [ node for node in path ]
        self.route = route

    def __eq__(self, other):
        if not isinstance(other, Route):
            return False
        return self.path == other.path

    def __lt__(self, other):
        return self.dist < other.dist

    def __hash__(self, other):
        return hash(self.path)

    def __str__(self):
        return "->".join(sorted(map(str, self.path)))

    def __repr__(self):
        return str(self)

    def getRoute(self, start=None):
        if start == None:
            return self.route[:]
        
        return self.route[:] if self.route[0] == start else self.route[::-1]
