#!/usr/bin/python3

if __name__ == '__main__':
    from Route import Route
else:
    from .Route import Route

from math import inf, radians 
from numpy import arcsin, sin, cos, sqrt
from itertools import permutations

class BruteForce():
    def __init__(self):
        self.name = "Brute Force"
        self.optimal_routes = None

    def optimal_assignment(self, initial_positions, destinations, force_update = False):
        if self.optimal_routes == None or force_update:
            self.optimal_routes = BruteForce._djikstra(set(initial_positions).pop())

        assignments = BruteForce._optimal_assignment(initial_positions, destinations, self.optimal_routes)

        return ( ( assign, self.optimal_routes.get(frozenset(assign), Route({*assign}, 0)) ) for assign in assignments )

    # arguments are list, list, mapping
    def _optimal_assignment(initial_positions, destinations, optimal_routes):
        perms = permutations(destinations)
        assignments = ( list(map(tuple, zip(perm, initial_positions)))
            for perm in perms )

        def assignment_value(assignment):
            # Anything not in the dictionary will have the form {a, a}
            # Which should report distance 0
            return sum(optimal_routes.get(frozenset(r), Route({}, 0)).dist for r in assignment)

        return min(assignments, key=assignment_value)

    # argument should be one node with a "neighbours"
    # attribute that contains elements of the form
    # ( neighbour node, distance)
    def _djikstra(a_node):
        shortest_known = dict()
        visited = set()
        to_visit = {a_node}

        def _safe_upate(k, v):
            old = shortest_known.get(k, None)
            if old == None:
                shortest_known[k] = v
            else:
                shortest_known[k] = min(old, v)

        while to_visit:
            current = to_visit.pop()
            visited.add(current)

            for nbr, dist in current.neighbours:
                curr_route = frozenset({current, nbr})

                if nbr not in visited:
                    to_visit.add(nbr)
                    _safe_upate(curr_route, Route(curr_route, dist))

                old_paths = list(shortest_known.keys())
                for path in old_paths:
                    r = path ^ curr_route
                    if len(r) == 2:
                        old_r = shortest_known[path]
                        to_add, sentinel = set(r - path).pop(), set(r & path).pop()
                        new_route = [to_add] + old_r.route if old_r.route[0] != sentinel else old_r.route + [to_add]
                        new_r = Route(r, old_r.dist + dist, new_route)
                        _safe_upate(r, new_r)

        return shortest_known

class PartialBruteForce():
    def __init__(self):
        self.name = "Heuristic Brute Force"
        self.optimal_routes = None

    def optimal_assignment(self, initial_positions, destinations, force_update = False):
        optimal_routes = self._djikstra(initial_positions, destinations)

        used = dict()
        assignments = []
        for dest in destinations:
            distance = lambda start: optimal_routes[frozenset({start, dest})].dist
            fully_used = {k for k, v in used.items() if v == sum(1 for v in k.vehicles if v.is_available())}
            opt = min(initial_positions - fully_used, key=distance)
            opt_key = frozenset({opt, dest})
            if optimal_routes[opt_key].dist == inf:
                assignment = self._error_reroute(initial_positions - fully_used, dest)
                assignments.append(assignment)
                used[assignment[0][0]] = used.get(assignment[0][0], 0) + 1
            else:
                used[opt] = used.get(opt, 0) + 1
                assignments.append(([opt, dest], optimal_routes[opt_key]))

        return assignments
        
    def _heuristic(self, start, dest):
        r_earth = 6371
        a1, b1 = map(radians, start.pos)
        a2, b2 = map(radians, dest.pos)
        hav = lambda x1, x2: sin( (x2 - x1)/2 ) ** 2
        return 2 * r_earth * arcsin( sqrt( hav(a1, a2) + cos(a1) * cos(a2) * hav(b1, b2) ) )

    def _error_reroute(self, starts, dest):
        print("did error reroute")
        best_guess = min(starts, key=lambda s: self._heuristic(s, dest))
        route = self._djikstra({best_guess}, {dest})[frozenset({best_guess, dest})]
        return ( [best_guess, dest], route )

    # Use A* to improve performance
    def _djikstra(self, initial_positions, destinations, shortest_known=None):
        if shortest_known == None:
            shortest_known = dict()

        overall_shortest = dict()

        for start in initial_positions:
            visited = set()
            to_visit = {start}

            # Distance from start to node
            inter_dist = {start: 0}
            # Optimal previous nodes
            prev_opt = dict()

            for dest in destinations:
                # Distance from node to end
                guess_dist = {start: self._heuristic(start, dest)}
                if guess_dist[start] > 1 * overall_shortest.get(dest, inf):
                    shortest_known[frozenset({start, dest})] = Route(frozenset({start, dest}), inf, route=[])
                    continue

                # This should run until we reach the destination
                while to_visit:
                    current = min(to_visit, key=lambda n:guess_dist.get(n, inf))
                    if current == dest:
                        break

                    to_visit.remove(current)
                    visited.add(current)

                    for nbr, dist in current.neighbours:
                        if nbr in visited:
                            continue

                        to_visit.add(nbr)
                        path_dist = inter_dist[current] + dist
                        if path_dist < inter_dist.get(nbr, inf):
                            prev_opt[nbr] = current
                            inter_dist[nbr] = path_dist
                            guess_dist[nbr] = path_dist + self._heuristic(nbr, dest)

                route = [dest]
                while route[-1] != start:
                    route.append(prev_opt[route[-1]])
                shortest_known[frozenset({start, dest})] = Route(frozenset({start, dest}), inter_dist[dest], route=route)
                overall_shortest[dest] = min(overall_shortest.get(dest, inf), inter_dist[dest])

        return shortest_known


# If run as a script, run a test case
if __name__ == '__main__':
    class Node():
        def __init__(self, name):
            self.name = name
            self.neighbours = set()
        def __eq__(self, other):
            return self.name == other.name
        def __hash__(self):
            return hash(self.name)
        def __str__(self):
            return self.name
        def __repr__(self):
            return self.name
        def __lt__(self, other):
            return self.name < other.name

    ### Visualisation of test ###
    #############################
    # ------5------
    # |           |
    # |           |
    # |           |
    # a -2- b     c ---|
    # |       \        |
    # |1       \3      |
    # |          \     5
    # d -3- e -3- f    |
    # |     |     |    |
    # |1    |3    |2   |
    # |     |     |    |
    # g -2- h -5- i ---|

    a = Node("a")
    b = Node("b")
    c = Node("c")
    d = Node("d")
    e = Node("e")
    f = Node("f")
    g = Node("g")
    h = Node("h")
    i = Node("i")

    a.neighbours = {(b, 2), (c, 5), (d, 1)}
    b.neighbours = {(a, 2), (f, 3)}
    c.neighbours = {(a, 5), (i, 5)}
    d.neighbours = {(a, 1), (e, 3), (g, 1)}
    e.neighbours = {(d, 3), (f, 3), (h, 3)}
    f.neighbours = {(e, 3), (i, 2)}
    g.neighbours = {(d, 1), (h, 2)}
    h.neighbours = {(e, 3), (g, 2), (i, 5)}
    i.neighbours = {(f, 2), (h, 5), (c, 5)}

    customer_nodes = [a, e, g, i]
    vehicle_nodes = [b, c, c, c, g]

    strat = BruteForce()
    assignments = strat.optimal_assignment(vehicle_nodes, customer_nodes)
    routes = strat.optimal_routes

    for key in sorted(routes, key=lambda fs:sorted(map(str, fs))):
        value = routes[key]
        print(str(value) + ": " + str(value.route) + " = " + str(value.dist))

    print("\nAssignments:")
    for assignment in assignments:
        if len(set(assignment[0])) == 1:
            print("->".join(str(assignment[0][0]) * 2) + ": " + str(assignment[1].route))
        else:
            print("->".join(map(str, assignment[0])) + ": " + str(assignment[1].route))
