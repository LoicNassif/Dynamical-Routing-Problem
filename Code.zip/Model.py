#!/usr/bin/python3

from time import time as clk

class Model():
    def __init__(self, city, customers, drivers, router, can_reroute):
        self.city = city
        self.customers = customers
        self.drivers = drivers
        self.router = router
        self.can_reroute = can_reroute

        self.duration = 8 * 60 # minutes
        self.step_size = 1 # minutes

        self.nodes_with_customers = set()
        for driver in self.drivers:
            driver.location.vehicles.add(driver)

        # Data fields
        self.wait_hist = []
        self.vehicle_usage = []
        self.customers_waiting = []
        if self.can_reroute:
            self.num_reroutes = 0

    def step(self):
        # Timing
        start_time = clk()

        # Make new customers arrive
        new_customers = customers.step(self.step_size).items()
        for position, number in new_customers:
            city[position].customers.extend(number * [self.duration])
            self.nodes_with_customers.add(city[position])

        # Do routing
        nodes_with_vehicles = {v.location for v in self.drivers if v.is_available()}
        if self.nodes_with_customers:
            assignments = router.optimal_assignment( nodes_with_vehicles, self.nodes_with_customers)

            got_new_route = set()
            for (v_loc, cus_loc), new_route in assignments:
                assignee = {v for v in v_loc.vehicles if v.is_available()}.pop()
                route = new_route.getRoute(assignee.location)[1:]
                if self.can_reroute and assignee.route != None:
                    if assignee.route[-1:] != [cus_loc]:
                        self.num_reroutes += 1
                assignee.setRoute(route)
                got_new_route.add(assignee)

                if not self.can_reroute:
                    self.nodes_with_customers.discard(cus_loc)

            if self.can_reroute:
                for vehicle in self.drivers:
                    if vehicle not in got_new_route:
                        vehicle.clearRoute()

        # Collect some data
        self.vehicle_usage.append(sum(v.route != None or v.passenger_steps > 0
            for v in self.drivers) / len(self.drivers))

        self.customers_waiting.append(sum(len(node.customers) for node in self.city))

        # Vehicles move based on routing
        for vehicle in drivers:
            vehicle.location.vehicles.remove(vehicle)
            vehicle.drive()
            vehicle.location.vehicles.add(vehicle)

        # Vehicles pick up customers
        for vehicle in drivers:
            if can_reroute and len(vehicle.location.customers) > 0:
                time_started_waiting = vehicle.location.customers.pop(0)
                tot_wait = time_started_waiting - self.duration + self.step_size
                self.wait_hist.append(tot_wait)
                vehicle.pickup_passenger()
                if len(vehicle.location.customers) == 0:
                    self.nodes_with_customers.remove(vehicle.location)
            elif not can_reroute and vehicle.route != None and len(vehicle.route) == 0:
                time_started_waiting = vehicle.location.customers.pop(0)
                tot_wait = time_started_waiting - self.duration + self.step_size
                self.wait_hist.append(tot_wait)
                vehicle.pickup_passenger()

        # Timing
        #print(clk() - start_time)
        print(self.duration)

        self.duration -= self.step_size
        return not self.is_done()

    def run(self):
        while self.step():
            ...

    def is_done(self):
        return self.duration == 0

    def _available_drivers(self):
        return filter(lambda v:v.is_available(), self.drivers)

def load_pedestrian_data_from_csv(filename):
    import csv
    mapping = dict()
    with open(filename, 'r') as csv_file:
        reader = csv.reader(csv_file, delimiter=',', quotechar='"')
        title_line = next(reader)
        for name, n_p, _, one_h, _, weight, _, customers_in_1_hr, _, weight_c in reader:
            cust_per_hour = float(customers_in_1_hr)
            cust_per_min = 1210 / 26862 * cust_per_hour / 60
            mapping[name] = cust_per_min

    return mapping


if __name__ == '__main__':
    from random import choice

    import City.nodes_network as City
    import Customer_Arrival.VariantRates as Customers
    import Route_Finding.Djikstra as Routing
    import VehicleBehaviour.HumanDrivers as Drivers

    Node = City.Node
    city = City.load_network('nodes.py')
    for node in city:
        node.vehicles = set()
        node.customers = []

    # For identical nodes
    rate_per_min = 60000 / 26862 * 1210 / 24 / 60 / 1210
    customers = Customers.DefaultCustomers( [ rate_per_min for _ in range(len(city))] )
    # For loaded nodes
    #cust_data = load_pedestrian_data_from_csv('Pedestrian-data.csv')
    #customers = Customers.DefaultCustomers( [ cust_data[node.name] for node in city ] )

    router = Routing.PartialBruteForce()
    
    can_reroute = True
    num_drivers = int(len(city) / 26862 * 5000 / 3)
    drivers = [ Drivers.DefaultDriver(choice(city), can_reroute) for _ in range(num_drivers) ]

    model = Model(city, customers, drivers, router, can_reroute)
    model.run()

    import matplotlib.pyplot as plt
    import numpy as np

    f_hist = plt.figure()
    plt.hist(model.wait_hist, bins=range(max(model.wait_hist)), rwidth=0.75, align='left')
    plt.xlabel("Wait time (minutes)")
    plt.ylabel("Number of customers")
    plt.title("Customer wait times: mean = {0:.3f} median = {1:.3f} std = {2:.3f}".format(
        np.mean(model.wait_hist), np.median(model.wait_hist), np.std(model.wait_hist)))

    f_vehicle = plt.figure()
    plt.plot(range(1, 481), model.vehicle_usage)
    plt.xlabel("Simulation Time (minutes)")
    plt.ylabel("Percentage of busy vehicles")
    plt.title("Vehicle Usage: mean = {0:.3f}".format(np.mean(model.vehicle_usage)))

    f_customer = plt.figure()
    plt.plot(range(1, 481), model.customers_waiting)
    plt.xlabel("Simulation Time (minutes)")
    plt.ylabel("Number of customers waiting")
    plt.title("Total Waiting Customers: mean = {0:.3f}".format(np.mean(model.customers_waiting)))

    plt.show()

    if can_reroute:
        print("Number of reroutes:", model.num_reroutes)

    print("Total customers:", len(model.wait_hist))

    input()
