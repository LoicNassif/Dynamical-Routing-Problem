# -*- coding: utf-8 -*-
"""
Created on Mon Mar 26 23:48:18 2018

@author: loic
"""
import json
from random import randint
from math import pi, sin, cos, sqrt, inf
from numpy import arcsin
import copy
import pickle

class Node:
    
    def __init__(self, name, position):
        self.name = name
        self.active = []
        self.car = 0
        self.vehicles = set()
        self.pop = 0
        self.n_customers = 0
        self.neighbours = []
        self.pos = position

    def __eq__(self, other):
        return isinstance(other, Node) and self.name == other.name

    def __hash__(self):
        return hash(self.name)

    def __str__(self):
        return self.name

    def __repr__(self):
        return self.name

#Run this on nodes after running main() to randomly initialize its neighbours
def rand_network(nodes):
    for i in range(len(nodes) - 1):
        nodes[i].neighbours.append( [nodes[i+1], 0] )
        nodes[i+1].neighbours.append( [nodes[i], 0] )
    
    for node in nodes:
        flag = True
        j = 0
        while flag and j < 500:
            j += 1
            rand = randint(0, len(nodes) - 1)
            if nodes[rand].name != node.name:
                if nodes[rand] not in node.neighbours:
                    node.neighbours.append( [nodes[rand], 0] )
                    nodes[rand].neighbours.append( [node, 0] )
                    flag = False
    find_distance(nodes)

    return nodes

def org_network(nodes):
    visited = set(nodes)
    for node in nodes:
        visited.remove(node)
        num_nbrs = len(node.neighbours)
        minn = [[None, inf]] * ( 4 - num_nbrs )
        if not minn:
            continue

        for other in visited: 
            d = haversine(6371, node.pos[0], other.pos[0], node.pos[1],
                    other.pos[1])
            if d < min([dist for node, dist in minn]):
                minn.append([other, d])
                minn = sorted(minn, key=lambda p:p[1])[:-1]
        
        for i in range(len(minn)):
            if minn[i][0] != None:
                node.neighbours.append(minn[i])
                minn[i][0].neighbours.append([node, minn[i][1]])

    return nodes

def sparse_network(nodes):
    nodes = org_network(nodes, 1)
    visited = {nodes[0]}
    to_visit = {n for n, d in nodes[0].neighbours}
    while not len(nodes) == len(visited):
        while to_visit:
            node = to_visit.pop()
            visited.add(node)
            to_visit.update({n for n, d in node.neighbours} - visited)

        rest = set(nodes) - visited
        if len(rest) == 0:
            break
        visited_node = set(visited).pop()
        rest_node = rest.pop()
        visited_node.neighbours.append(rest_node)
        d = haversine(6371, visited_node.pos[0], rest_node.pos[0], 
                      visited_node.pos[1], rest_node.pos[1])
        rest_node.neighbours.append([visited_node, d])
        to_visit.add(rest_node)

def check_valid_link(nodes):
    check = True
    for node in nodes:
        for neigh in node.neighbours:
            i = 0
            for other in neigh[0].neighbours:
                if other[0].name == node.name:
                    i += 1
            if i == 0:
                check = False
    
    return check
            
def find_distance(nodes):
    for node in nodes:
        for neigh in node.neighbours:
            d = haversine(6371, node.pos[0], neigh[0].pos[0], node.pos[1], 
                      neigh[0].pos[1])
            neigh[1] = d

def haversine(r, a1, a2, b1, b2):
    """Haversine function to find distances on a curved surface.
    a1, a2: latitude of point 1 and 2
    b1, b2: longitude of point 1 and 2
    """
    a1 = (pi/180)*a1
    a2 = (pi/180)*a2
    b1 = (pi/180)*b1
    b2 = (pi/180)*b2

    part1 = sin(0.5*(a2 - a1))**2
    part2 = cos(a1)*cos(a2)*(sin(0.5*(b2 - b1))**2)
    return 2*r*arcsin(sqrt(part1 + part2))

def load_network(file):
    import os
    filename = os.path.join(os.path.dirname(__file__), file)
    with open(filename, 'rb') as f:
        data = pickle.load(f)
    
    for node in data:
        for nbr in node.neighbours:
            nbr[0] = data[nbr[0]]
    
    return data

def save_network(nodes):
    nodez = list(nodes)
    for node in nodez:
        for neigh in node.neighbours:
            neigh[0] = nodez.index(neigh[0])
            
    pickle.dump(nodez, open('nodes.py', 'wb'))

def dic_to_node(data):
    nodes = []
    for key in data:
        node = Node(key, data[key][1])
        node.car = data[key][2][0]
        node.pop = data[key][2][1]
        nodes.append(node)
    
    return nodes

#main()
def main():
    import os
    filename = os.path.join(os.path.dirname(__file__), 'data1.json')
    with open(filename, 'r') as fp:
        data1 = json.load(fp)

    nodes = dic_to_node(data1)
    
    return org_network(nodes)
