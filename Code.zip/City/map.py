from mapsplotlib import mapsplot as mplt
import pickle
import nodes_network as City
from pandas import DataFrame

def nodes_to_dic(nodes):
    dic = {}
    dic['latitude'] = []; dic['longitude'] = []; dic['color'] = []
    dic['size'] = []; dic['label'] = []
    for node in nodes:
        dic['latitude'].append(node.pos[0])
        dic['longitude'].append(node.pos[1])
        dic['size'].append('mid')
        dic['label'].append(node.name)
        dic['color'].append('red')

    return dic

if __name__ == '__main__':
    Node = City.Node
    city = City.load_network('nodes.py')
    dic = nodes_to_dic(city)
    lateral = ''
    start = 'https://maps.googleapis.com/maps/api/staticmap?center=Upper+Village,Toronto,ON&zoom=12&size=900x600&maptype=roadmap'
    for i in range(len(dic['size'])):
        lateral += ('&markers=color:'+str(dic['color'][i])+'%7Clabel:'
        +'%7C'+str(dic['latitude'][i])+','+str(dic['longitude'][i]))

    print(start+lateral+'&key=AIzaSyAmESQkeiUwTHppK4at4DTYfZfZoyWG7Yk')


# https://maps.googleapis.com/maps/api/staticmap?center=Upper+Village,Toronto,ON
# &zoom=12&size=900x600&maptype=roadmap&markers=color:blue%7Clabel:S%7C43.85545,-79.63929
# &markers=color:green%7Clabel:G%7C43.87545,-79.43929&markers=color:red%7Clabel:C%7C43.75545,-79.53929
# &key=AIzaSyAmESQkeiUwTHppK4at4DTYfZfZoyWG7Yk
